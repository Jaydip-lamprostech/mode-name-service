import React from "react";

function DomainNotPurchased() {
  return <div>DomainNotPurchased</div>;
}

export default DomainNotPurchased;
